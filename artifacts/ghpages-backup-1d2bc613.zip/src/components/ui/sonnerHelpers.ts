import { Toaster as Sonner, toast } from "sonner";

export { Sonner as SonnerToaster, toast };
