import { RetroImageEditor } from '@/components/RetroImageEditor';

const Index = () => {
  return <RetroImageEditor />;
};

export default Index;
