# Welcome to your Lovable project

## Project info

**URL**: https://lovable.dev/projects/c17be190-7ca5-4ab4-9d2f-2249fe4ed289

## How can I edit this code?

There are several ways of editing your application.

**Use Lovable**

Simply visit the [Lovable Project](https://lovable.dev/projects/c17be190-7ca5-4ab4-9d2f-2249fe4ed289) and start prompting.

Changes made via Lovable will be committed automatically to this repo.

**Use your preferred IDE**

If you want to work locally using your own IDE, you can clone this repo and push changes. Pushed changes will also be reflected in Lovable.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

Simply open [Lovable](https://lovable.dev/projects/c17be190-7ca5-4ab4-9d2f-2249fe4ed289) and click on Share -> Publish.

## Can I connect a custom domain to my Lovable project?

Yes, you can!

To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.

Read more here: [Setting up a custom domain](https://docs.lovable.dev/tips-tricks/custom-domain#step-by-step-guide)

## Testing / Dev notes

If you want to test the camera preview or run the dev server locally, follow these quick steps:

- Start the dev server:

```powershell
npm install
npm run dev
```

- Open the local URL printed by Vite (for example `http://localhost:5173/` or `http://localhost:8082/`).

- To verify the camera preview sizing in the app, open DevTools → Console and run the following snippet. It prints the video metadata and container geometry used by the preview UI:

```javascript
(() => {
	const res = { location: location.href, protocol: location.protocol, isSecureContext: window.isSecureContext };
	const video = document.querySelector('video');
	res.videoFound = !!video;
	if (video) {
		const rect = video.getBoundingClientRect();
		res.videoRect = { w: Math.round(rect.width), h: Math.round(rect.height) };
		res.videoMeta = { videoWidth: video.videoWidth, videoHeight: video.videoHeight };
		try {
			const tracks = video.srcObject ? (video.srcObject).getVideoTracks() : [];
			if (tracks && tracks.length) res.trackSettings = tracks[0].getSettings ? tracks[0].getSettings() : null;
		} catch (e) { res.trackSettingsError = String(e); }
	}

	const previewDiv = Array.from(document.querySelectorAll('div[style]')).find(d => /px/.test(d.style.height || ''));
	if (previewDiv) {
		const b = previewDiv.getBoundingClientRect();
		res.previewDiv = { clientWidth: previewDiv.clientWidth, offsetWidth: previewDiv.offsetWidth, rect: { w: Math.round(b.width), h: Math.round(b.height) }, computed: getComputedStyle(previewDiv).cssText };
	}
	return res;
})();
```

- Notes:
	- Temporary dev/test scripts and screenshots created during troubleshooting have been removed from the repository.
	- If you want me to add back a small, documented checker script (that does not commit artifacts), tell me and I'll add it under `scripts/` with a descriptive README entry.

